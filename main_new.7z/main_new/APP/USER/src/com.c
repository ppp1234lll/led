#include "appconfig.h"

#define COM_HEAD_HEX (0x0F0F) 		// ����ͷ
#define COM_TAIL_HEX (0xFFFF) 		// ����β

#define COM_REC_HAED_HEX (0xF0F0) 	// ��������ͷ
#define COM_NUM_VAERSION (0x11) 	// ���ݰ汾
static struct com_qn_t sg_comqn_t; // �����ʶ��
	
/************************************************************
*
* Function name	: com_report_get_adapter_status
* Description	: ��ȡ������״̬
* Parameter		: 
*	@adapter	: ���������
* Return		: 0-������ 1-ͨ�� 2-�ϵ�
*	
************************************************************/
uint8_t com_report_get_adapter_status(uint8_t adapter)
{
	uint8_t status = 0;
	
	switch(adapter)
	{
		case 0:
			if(relay_get_status(RELAY_1) == RELAY_ON) 
				status = 1;
			else 	/* ����ͷ�ϵ� */
				status = 2;
			
			break;
		case 1:
//			status = 0;
			if(relay_get_status(RELAY_2) == RELAY_ON) 
				status = 1;
			else 			/* ����ͷ�ϵ� */
				status = 2;
			break;
		case 2:
			status = 0;
			break;
	}
	return status;
}

/************************************************************
*
* Function name	: com_report_get_camera_status
* Description	: ��ȡ���������״̬
* Parameter		: 
*	@camera		: ��������
* Return		: 0-������ 1-�������� 2-����Ͽ�
*	
************************************************************/
uint8_t com_report_get_camera_status(uint8_t camera)
{
	uint8_t ip[4]  = {0};
	uint8_t status = 0;
	
	if(app_get_camera_function(ip,camera) < 0)
	{
		status = 0;			// ������
	}
	else
	{
		if(eth_get_network_cable_status() == 0)
		{
			status = 2; 			// ����Ͽ�
		}
		else 
		{
			if ( det_get_camera_status(camera) == 1 ) 
				status = 1;		// ��������
			else if ( det_get_camera_status(camera) == 2 )   // ������ʱʱ��  20220308
				status = 4;		// ������ʱ����
			else 
				status = 2;		// �����쳣
		}
	}
	return status;
}

/************************************************************
*
* Function name	: com_report_get_main_network_status
* Description	: ��ȡ������״̬
* Parameter		: 
*	@main		: 0-������1 1-������2
* Return		: 0-δָ��IP 1-�������� 2-����Ͽ� 3-�豸����Ͽ�
*	
************************************************************/
uint8_t com_report_get_main_network_status(uint8_t main)
{
	uint8_t ip[4]  = {0};
	uint8_t status = 0;
	
	switch(main) 
	{
		case 0:			/* ������״̬1 */
			if(eth_get_network_cable_status() == 0) 
			{
				status = 3;
			} 
			else 
			{
				app_get_main_network_ping_ip_addr(ip);
				if(ip[0] == 0 && ip[1] == 0 && ip[2] == 0 && ip[3] == 0) 
				{
					status = 0;				// ������
				} 
				else 
				{
					if( det_get_main_network_status() == 1)
						status = 1;			// ��������
					else if( det_get_main_network_status() == 2)  // ������ʱʱ��  20220308
						status = 4;			// ������ʱ����
					else
						status = 2;			// ����Ͽ�
				}
			}
			break;
		/* ������״̬2 */
		case 1:
			app_get_main_network_sub_ping_ip_addr(ip); 
			if(ip[0] == 0 && ip[1] == 0 && ip[2] == 0 && ip[3] == 0) 
			{
				status = 0;					// ������
			} 
			else 
			{
				if( det_get_main_network_sub_status() == 1) 
					status = 1;				// ��������
				else if( det_get_main_network_sub_status() == 2)  // ������ʱʱ��  20220308
					status = 4;			// ������ʱ����
				else 
					status = 2;				// ����Ͽ�
			}
			break;
	}
	return status;
}

/*
*********************************************************************************************************
*	�� �� ��: com_report_normally_function
*	����˵��: �����ϱ�
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void com_report_normally_function(uint8_t *data, uint16_t *len, uint8_t cmd)
{
	struct device_param *device = app_get_device_param_function();
	uint16_t 		index   = 0;
	uint16_t		size    = 0;
	uint8_t			crc			= 0;
	uint8_t  		str[64] ={0};
	uint8_t			*p			= 0;
	uint16_t		buff[4] ={0};
	fp32				temp 		= 0;
	char 			  str_buff[8][8] = {0};
	
	/* ����ͷ */
	data[index++] = '#';
	data[index++] = '#';
	/* ���ݳ��� */
	data[index++] = '0';
	data[index++] = '0';
	data[index++] = '0';
	data[index++] = '0';
	/* �������QN */
	memset(str,0,sizeof(str));
	
	if(sg_comqn_t.flag == 1) {
		/* �����ϱ� */
		sg_comqn_t.flag = 0;
		sprintf((char*)str,"QN=%08d%09d;",sg_comqn_t.qn1,sg_comqn_t.qn2);
		strcat((char*)data,(char*)str);
		sg_comqn_t.qn1 = 0;
		sg_comqn_t.qn2 = 0;
	} else {
		/* �����ϱ� */
		sprintf((char*)str,"QN=0;");
		strcat((char*)data,(char*)str);
	}
	
	/* �豸Ψһ��ʶTID */
	memset(str,0,sizeof(str));
	sprintf((char*)str,"TID=%d;",device->id.i);
	strcat((char*)data,(char*)str);
	/* �汾�� */
	memset(str,0,sizeof(str));
	sprintf((char*)str,"VER=%02x;",COM_DATA_VERSION);
	strcat((char*)data,(char*)str);
//	strcat((char*)data,"VER=11;");
	/* ָ�����CP */
	strcat((char*)data,"CP=&&");
	
	/** ϵͳʱ�� **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"DT=%s;",app_get_report_current_time(0));
	strcat((char*)data,(char*)str);

	/** �����������״̬ **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"CNS=%01d,%01d,%01d,%01d,%01d,%01d;",
											com_report_get_camera_status(0),
											com_report_get_camera_status(1),
											com_report_get_camera_status(2),
											com_report_get_camera_status(3),
											com_report_get_camera_status(4),
											com_report_get_camera_status(5));
	strcat((char*)data,(char*)str);
	/** ��������״̬ **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"MN=%d,%d;", com_report_get_main_network_status(0),
																	com_report_get_main_network_status(1));
	strcat((char*)data,(char*)str);
	/** ��ѹ������ **/
	memset(str,0,sizeof(str));
	temp = det_get_vin220v_handler(0);
	buff[0] = (uint16_t)temp;
	buff[1] = temp*100-buff[0]*100;
	temp = det_get_vin220v_handler(1);
	buff[2] = (uint16_t)temp;
	buff[3] = temp*100-buff[2]*100;
	sprintf((char*)str,"V=%d.%02d;A=%d.%02d;",buff[0],buff[1],buff[2],buff[3]);
	strcat((char*)data,(char*)str);
	/** ʪ�ȡ��¶� **/
	memset(str,0,sizeof(str));
	temp = det_get_inside_humi();
	buff[0] = (uint16_t)temp;
	buff[1] = temp*100-buff[0]*100;
	temp = det_get_inside_temp();
	if(temp < 0) {
		temp = 0 - temp;
		buff[2] = (uint16_t)temp;
		buff[3] = temp*100-buff[2]*100;
		sprintf((char*)str,"H=%d.%02d;T=-%d.%02d;",buff[0],buff[1],buff[2],buff[3]);
	} else {
		buff[2] = (uint16_t)temp;
		buff[3] = temp*100-buff[2]*100;
		sprintf((char*)str,"H=%d.%02d;T=%d.%02d;",buff[0],buff[1],buff[2],buff[3]);
	}	
	strcat((char*)data,(char*)str);
	/** ��״̬��������̬������״̬ **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"DS=%01d;P=%d;SPD=%01d;",
											(det_get_door_status()),
											 det_get_cabinet_posture(),
											 det_get_spd_status());
	strcat((char*)data,(char*)str);
	/** �豸����**/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"PA=%01d;",det_get_pwr_status());
	strcat((char*)data,(char*)str);
	
	/** ��ѹ Ƿѹ���������� **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"OV=%01d;OCPS=%01d;",app_get_vlot_protec_status(),\
                                          app_get_current_status());
	strcat((char*)data,(char*)str);

	/** ˮ����� **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"WATER=%01d;",det_get_water_status());
	strcat((char*)data,(char*)str);

	/** �ܹ��� ���õ��� **/
	memset(str,0,sizeof(str));
	memset(str_buff,0,sizeof(str_buff));
	Vin220_Power_Handler(str_buff[0],0);
	Vin220_Elec_Handler (str_buff[1],0);
	sprintf((char*)str,"APOWER=%s;AKW=%s;",str_buff[0],str_buff[1]);
	strcat((char*)data,(char*)str);	
	
	/** �̵���״̬ **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"RELAY=%01d,%01d,%01d,%01d,%01d;",
											relay_get_status(RELAY_1),relay_get_status(RELAY_2),
											relay_get_status(RELAY_3),relay_get_status(RELAY_4),
											relay_get_status(RELAY_5));
	strcat((char*)data,(char*)str);

	/** ֧·��ѹ **/
	memset(str,0,sizeof(str));
	memset(str_buff,0,sizeof(str_buff));
	for(uint8_t i=0;i< 5 ;i++)
	{
		if(relay_get_status((RELAY_DEV)i) == 1)
			Vin220_Handler(str_buff[i],0);
		else
			sprintf(str_buff[i],"%d",0);
	}	
	sprintf((char*)str,"CHV=%s,%s,%s,%s,%s;",
											str_buff[0],str_buff[1],str_buff[2],str_buff[3],str_buff[4]);
	strcat((char*)data,(char*)str);
	
	/** ֧·���� **/
	memset(str,0,sizeof(str));
	memset(str_buff,0,sizeof(str_buff));
	for(uint8_t i=0;i<5;i++)
		Vin220_Handler(str_buff[i],2+i);

	sprintf((char*)str,"CHA=%s,%s,%s,%s,%s;",
											str_buff[0],str_buff[1],str_buff[2],str_buff[3],str_buff[4]);
	strcat((char*)data,(char*)str);
	
	/** ���� **/
	memset(str,0,sizeof(str));
	memset(str_buff,0,sizeof(str_buff));
	for(uint8_t i=0;i< 5;i++)
		Vin220_Power_Handler(str_buff[i],1+i);
	sprintf((char*)str,"POWER=%s,%s,%s,%s,%s;",
											str_buff[0],str_buff[1],str_buff[2],str_buff[3],str_buff[4]);
	strcat((char*)data,(char*)str);

	/** �õ��� **/
	memset(str,0,sizeof(str));
	memset(str_buff,0,sizeof(str_buff));
	for(uint8_t i=0;i< 5;i++)
		Vin220_Elec_Handler(str_buff[i],1+i);
	sprintf((char*)str,"ELEC=%s,%s,%s,%s,%s;",
											str_buff[0],str_buff[1],str_buff[2],str_buff[3],str_buff[4]);
	strcat((char*)data,(char*)str);

	/** ©�� **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"MIU=%d;",app_get_miu_protec_status());
	strcat((char*)data,(char*)str);

		/** �̵���״̬ **/
	memset(str,0,sizeof(str));
	sprintf((char*)str,"DCR=%01d,%01d;",
											relay_get_status(MOS12V_1),relay_get_status(MOS12V_2));
	strcat((char*)data,(char*)str);
	
	/** ֱ����ѹ ���� ���� �õ��� **/
	memset(str,0,sizeof(str));
	memset(str_buff,0,sizeof(str_buff));
	DC12_Elec_Handler(str_buff[0],0);		// ��ѹ
	DC12_Elec_Handler(str_buff[1],1);		// ���� 1
	DC12_Elec_Handler(str_buff[2],2);		// ���� 2
	DC12_Elec_Handler(str_buff[3],3);		// �õ��� 3
	sprintf((char*)str,"DCV=%s;DCA=%s;DCP=%s;DCE=%s;",\
                        str_buff[0],str_buff[1],str_buff[2],str_buff[3]);
	strcat((char*)data,(char*)str);

	/** ��������Ϣ **/
	snmp_t *switch_data = snmp_get_switch_data();
	memset(str,0,sizeof(str));
	sprintf((char*)str,"MODEL=%s;UPTIME=%d;",
										switch_data->device_model,switch_data->uptime_ticks);
	strcat((char*)data,(char*)str);  
	
	memset(str,0,sizeof(str));
	sprintf((char*)str,"PORT_STATUS=%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d;",\
											switch_data->port_status[0],switch_data->port_status[1],\
											switch_data->port_status[2],switch_data->port_status[3],\
											switch_data->port_status[4],switch_data->port_status[5],\
											switch_data->port_status[6],switch_data->port_status[7],\
											switch_data->port_status[8],switch_data->port_status[9]);
	strcat((char*)data,(char*)str);

	memset(str,0,sizeof(str));
	sprintf((char*)str,"PORT_SPEED=%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d;",\
											switch_data->port_speed[0],switch_data->port_speed[1],\
											switch_data->port_speed[2],switch_data->port_speed[3],\
											switch_data->port_speed[4],switch_data->port_speed[5],\
											switch_data->port_speed[6],switch_data->port_speed[7],\
											switch_data->port_speed[8],switch_data->port_speed[9]);
	strcat((char*)data,(char*)str);
	
	memset(str,0,sizeof(str));
	sprintf((char*)str,"PORT_POE=%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d,%01d;",\
											switch_data->port_poe[0],switch_data->port_poe[1],\
											switch_data->port_poe[2],switch_data->port_poe[3],\
											switch_data->port_poe[4],switch_data->port_poe[5],\
											switch_data->port_poe[6],switch_data->port_poe[7],\
											switch_data->port_poe[8],switch_data->port_poe[9]);
	strcat((char*)data,(char*)str);	
	
	/** ������λ��Ϣֻ������γ�ȼ��� */
	atgm336h_data_t *gnss_data = atgm336h_get_gnss_data();
	sprintf((char*)str,"LAT=%.06f;LNG=%.06f;",
										fabs(gnss_data->latitude),fabs(gnss_data->longitude));
	strcat((char*)data,(char*)str);

	strcat((char*)data,"&&");
	
	/* ���ݳ��� */
	size = strlen((char*)data);
	sprintf((char*)str,"%04d",size-6);
	data[2] = str[0];
	data[3] = str[1];
	data[4] = str[2];
	data[5] = str[3];
	/* CRCУ�� */
	p = (uint8_t*)strstr((char*)data,"&&");
	if(p == 0) {
		*len = 0;
	} else {
		crc = calc_crc8(p,strlen((char*)p));
		memset(str,0,sizeof(str));
		sprintf((char*)str,"%02x##",crc);
		strcat((char*)data,(char*)str);
		*len = strlen((char*)data);
	}
}

/************************************************************
*
* Function name	: com_query_configuration_function
* Description	: ��ѯ����
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_query_configuration_function(uint8_t *pdata, uint16_t *len)
{
	struct device_param 	*device     = app_get_device_param_function();
	struct remote_ip    	*remote     = app_get_remote_network_function();
	struct local_ip_t   	*local      = app_get_local_network_function();
	       com_param_t    *comparam   = app_get_com_time_infor();
	       carema_t       *ipc        = app_get_carema_param_function();
	struct threshold_params *threshol = app_get_threshold_param_function();
	struct update_addr    *ota        = app_get_http_ota_function();	
	uint8_t name[5]     = {0};
	char  temp[128] 	= {0};
	char  crc_buff[20]	= {0};
	uint8_t crc		    = 0;
	uint8_t index 		= 0;
	
	/* ����У���� */
	sprintf(crc_buff,"%x%dE1",0x10,device->id.i);
	crc = calc_crc8((uint8_t*)crc_buff,strlen(crc_buff)-1);
	
	my_cjson_create_function(pdata,0); // ��ʼ
	my_cjson_join_int_function(pdata,(uint8_t *)"code",0,1);
	my_cjson_data_create_function(pdata,0); // ��ʼ

	/* �汾�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02x",COM_DATA_VERSION);
	my_cjson_join_string_function(pdata,(uint8_t *)"ver",(uint8_t *)temp,1);
//	my_cjson_join_string_function(pdata,(uint8_t *)"ver",(uint8_t *)"11",1);
	/* ����QN */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%08d%09d",sg_comqn_t.qn1,sg_comqn_t.qn2);
	my_cjson_join_string_function(pdata,(uint8_t *)"qn",(uint8_t *)temp,1);
    sg_comqn_t.qn1 = 0;
    sg_comqn_t.qn2 = 0;
    sg_comqn_t.flag = 0;
	
	/* ID */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",device->id.i);
	my_cjson_join_string_function(pdata,(uint8_t *)"tid",(uint8_t *)temp,1);
	/* ͨ������ */
	my_cjson_join_string_function(pdata,(uint8_t *)"cmd",(uint8_t *)"E1",1);

	/* �豸���� */
	my_cjson_join_string_function(pdata,(uint8_t *)"tn",(uint8_t *)app_get_device_name(),1);
	/* �ն����к� */
	memset(temp,0,sizeof(temp));
	start_get_device_id_str((uint8_t*)temp);
	my_cjson_join_string_function(pdata,(uint8_t*)"tsn",(uint8_t*)temp,1);

	/* ���������IP������+�˿� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%s:%d",remote->inside_iporname,remote->inside_port);
	my_cjson_join_string_function(pdata,(uint8_t*)"isi",(uint8_t*)temp,1);
	/* ����������IP������+�˿� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%s:%d",remote->outside_iporname,remote->outside_port);
	my_cjson_join_string_function(pdata,(uint8_t*)"osi",(uint8_t*)temp,1);
	
	/* ����������IP������+�˿� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d.%d.%d.%d:%d",ota->ip[0],ota->ip[1],ota->ip[2],ota->ip[3],ota->port);
	my_cjson_join_string_function(pdata,(uint8_t*)"usi",(uint8_t*)temp,1);

	/* SIM�����к� */
	my_cjson_join_string_function(pdata,(uint8_t*)"iccid",(uint8_t*)gsm_get_sim_ccid_function(),1);
	/* 4Gģ��IMEI */
	my_cjson_join_string_function(pdata,(uint8_t*)"imei",(uint8_t*)gprs_get_imei_function(),1);
	/* SIM���ź�ǿ�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",gprs_get_csq_function());
	my_cjson_join_string_function(pdata,(uint8_t*)"dbm",(uint8_t*)temp,1);
	/* ����ģʽ */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",app_get_network_mode());
	my_cjson_join_string_function(pdata,(uint8_t*)"tm",(uint8_t*)temp,1);
	/* ����MAC��ַ */
	my_cjson_join_string_function(pdata,(uint8_t*)"mac",lwip_get_mac_addr(),1);
	/* IP */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d.%d.%d.%d",local->ip[0],local->ip[1],local->ip[2],local->ip[3]);
	my_cjson_join_string_function(pdata,(uint8_t*)"ip",(uint8_t*)temp,1);
	/* �������� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d.%d.%d.%d",local->netmask[0],local->netmask[1],local->netmask[2],local->netmask[3]);
	my_cjson_join_string_function(pdata,(uint8_t*)"nm",(uint8_t*)temp,1);
	/* ���� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d.%d.%d.%d",local->gateway[0],local->gateway[1],local->gateway[2],local->gateway[3]);
	my_cjson_join_string_function(pdata,(uint8_t*)"gw",(uint8_t*)temp,1);
	/* �������IP */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d.%d.%d.%d,%d.%d.%d.%d", local->ping_ip[0],local->ping_ip[1],local->ping_ip[2],local->ping_ip[3],
											local->ping_sub_ip[0],local->ping_sub_ip[1],local->ping_sub_ip[2],local->ping_sub_ip[3]);
	my_cjson_join_string_function(pdata,(uint8_t*)"mip",(uint8_t*)temp,1);
	/* �ϱ���� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d,%d,%d",comparam->report/1000,0,0);
	my_cjson_join_string_function(pdata,(uint8_t*)"rt",(uint8_t*)temp,1);
	/* pingÿ�ּ��ʱ�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",comparam->ping/1000);
	my_cjson_join_string_function(pdata,(uint8_t*)"pl",(uint8_t*)temp,1);

	/* pingÿ���豸�ļ��ʱ�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",comparam->dev_ping/1000);
	my_cjson_join_string_function(pdata,(uint8_t*)"pn",(uint8_t*)temp,1);

	/* ����������ֹͣ�¶� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d,%d",threshol->temp_high,threshol->temp_low);
	my_cjson_join_string_function(pdata,(uint8_t*)"ft",(uint8_t*)temp,1);

	/* ��������ʪ�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d,%d",threshol->humi_high,threshol->humi_low);
	my_cjson_join_string_function(pdata,(uint8_t*)"fh",(uint8_t*)temp,1);

	/* ������ʱʱ������  20220308*/  
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",comparam->network_time);
	my_cjson_join_string_function(pdata,(uint8_t*)"pt",(uint8_t*)temp,1);

	/* �����IP */
	for(index=0;index<10;index++)
	{
		memset(temp,0,sizeof(temp));
		sprintf(temp,"%d.%d.%d.%d", ipc->ip[index][0],ipc->ip[index][1],\
																ipc->ip[index][2],ipc->ip[index][3]);
		sprintf((char*)name,"c%d",index+1);
		my_cjson_join_string_function(pdata,name,(uint8_t*)temp,1);
	}
	
	/* ��ѹ*/
//	memset(temp,0,sizeof(temp));
//	sprintf(temp,"%d",threshol->volt_max);
//  my_cjson_join_string_function(pdata,(uint8_t*)"ov",(uint8_t*)temp,1);
//	/* Ƿѹ*/
//	memset(temp,0,sizeof(temp));
//	sprintf(temp,"%d",threshol->volt_min);
//  my_cjson_join_string_function(pdata,(uint8_t*)"uv",(uint8_t*)temp,1);

//  /* ���� */
//	memset(temp,0,sizeof(temp));
//	sprintf(temp,"%d",threshol->current);
//  my_cjson_join_string_function(pdata,(uint8_t*)"oc",(uint8_t*)temp,1);

//	/* ��б�Ƕ� */  
//	memset(temp,0,sizeof(temp));
//	sprintf(temp,"%d",threshol->angle);
//	my_cjson_join_string_function(pdata,(uint8_t*)"angle",(uint8_t*)temp,1);

//	/* ©�� */  
//	memset(temp,0,sizeof(temp));
//	sprintf(temp,"%d",threshol->miu);
//	my_cjson_join_string_function(pdata,(uint8_t*)"miu",(uint8_t*)temp,1);

	/* ��ѹ��Ƿѹ����������б�ȡ�©��*/
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d,%d,%d,%d,%d",threshol->volt_max,threshol->volt_min,threshol->current,threshol->angle,threshol->miu);
  my_cjson_join_string_function(pdata,(uint8_t*)"opovc",(uint8_t*)temp,1);

	/* ����Э��ģʽ  20220908*/  
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",local->search_mode);
	my_cjson_join_string_function(pdata,(uint8_t*)"sm",(uint8_t*)temp,1);
	
	/* ����Э��ʱ������  20220908*/  
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",comparam->onvif_time);
	my_cjson_join_string_function(pdata,(uint8_t*)"smt",(uint8_t*)temp,1);
	
	/* ���½�� */  
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",threshol->angle);
	my_cjson_join_string_function(pdata,(uint8_t*)"ur",(uint8_t*)temp,1);
	
	/* ǩ��У�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%x",crc);
	my_cjson_join_string_function(pdata,(uint8_t*)"crc",(uint8_t*)temp,0);
	
	my_cjson_data_create_function(pdata,1); // ����
	my_cjson_create_function(pdata,1); // ����
	
	*len = strlen((char*)pdata);
	
	if(COM_DEBUG)   printf("%s \r\n",pdata);
}
	
/************************************************************
*
* Function name	: com_heart_pack_function
* Description	: ������
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_heart_pack_function(uint8_t *data, uint16_t *len)
{
	struct device_param *device = app_get_device_param_function();
	uint8_t 			index   = 0;
	uint16_t			crc     = 0;
	
	/* ����ͷ */
	data[index++] = (COM_HEAD_HEX&0xff00)>>8; 
	data[index++] = COM_HEAD_HEX&0xff;
	/* ���ݰ汾 */
	data[index++] = COM_DATA_VERSION;
//	data[index++] = COM_NUM_VAERSION;
	/* �豸ID */
	data[index++] = (device->id.i>>16)&0xff;
	data[index++] = (device->id.i>>8)&0xff;
	data[index++] = (device->id.i>>0)&0xff;
	/* ���� */
	data[index++] = COM_HEART_UPDATA;
	
	/* �����ʶ�� */
	data[index++] = 0;
	data[index++] = 0;
	data[index++] = 0;
	data[index++] = 0;
	
	data[index++] = 0;
	data[index++] = 0;
	data[index++] = 0;
	data[index++] = 0;
	
	/* ���ݳ��� */
	data[index++] = 0x01;

	/* �������� */
	data[index++] = 0x01;

	/* crcУ�� */
	crc = calc_crc8(&data[2],index-2);
	data[index++] = crc;
	
	/* ����β */
	data[index++] = (COM_TAIL_HEX>>8)&0xff;
	data[index++] = (COM_TAIL_HEX)&0xff;
	
	*len = index;
}

/************************************************************
*
* Function name	: com_ack_function
* Description	: �ظ�����
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_ack_function(uint8_t *data, uint16_t *len, uint8_t ack, uint8_t error)
{
	struct device_param *device = app_get_device_param_function();
	uint8_t 			index   = 0;
	uint16_t			crc     = 0;
	
	/* ����ͷ */
	data[index++] = (COM_HEAD_HEX&0xff00)>>8; 
	data[index++] = COM_HEAD_HEX&0xff;
	/* ���ݰ汾 */
	data[index++] = COM_DATA_VERSION;
//	data[index++] = COM_NUM_VAERSION;
	/* �豸ID */
	data[index++] = (device->id.i>>16)&0xff;
	data[index++] = (device->id.i>>8)&0xff;
	data[index++] = (device->id.i>>0)&0xff;
	/* ���� */
	data[index++] = ack;
	/* �����ʶ��QN */
	if(sg_comqn_t.flag == 1) {
		sg_comqn_t.flag = 0;
	}
	data[index++] = (sg_comqn_t.qn1>>24) & 0xff;
	data[index++] = (sg_comqn_t.qn1>>16) & 0xff;
	data[index++] = (sg_comqn_t.qn1>>8) & 0xff;
	data[index++] = (sg_comqn_t.qn1>>0) & 0xff;
	data[index++] = (sg_comqn_t.qn2>>24) & 0xff;
	data[index++] = (sg_comqn_t.qn2>>16) & 0xff;
	data[index++] = (sg_comqn_t.qn2>>8) & 0xff;
	data[index++] = (sg_comqn_t.qn2>>0) & 0xff;
    
	sg_comqn_t.qn1 = 0;
	sg_comqn_t.qn2 = 0;
	
	/* ���ݳ��� */
	data[index++] = 0x01;
	
	/* ������ */
	data[index++] = error;
	
	/* crcУ�� */
	crc = calc_crc8(&data[2],index-2);
	data[index++] = crc;
	
	/* ����β */
	data[index++] = (COM_TAIL_HEX>>8)&0xff;
	data[index++] = (COM_TAIL_HEX)&0xff;
	
	*len = index;
}

/************************************************************
*
* Function name	: com_version_information
* Description	: �ϴ�������Ӳ���汾��
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_version_information(uint8_t *pdata, uint16_t *size)
{
	struct device_param *device = app_get_device_param_function();
	char  temp[128] 	   = {0};
	char  crc_buff[50] = {0};
	uint8_t crc		   = 0;

	/* ��ȡcrcУ���� */
	sprintf(crc_buff,"%x%dE3",0x10,device->id.i);
	crc = calc_crc8((uint8_t*)crc_buff,strlen(crc_buff)-1);
	
	my_cjson_create_function(pdata,0); // ��ʼ
	my_cjson_join_int_function(pdata,(uint8_t *)"code",0,1);
	
	/* ����QN */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%08d%09d",sg_comqn_t.qn1,sg_comqn_t.qn2);
	my_cjson_join_string_function(pdata,(uint8_t *)"qn",(uint8_t *)temp,1);
    sg_comqn_t.qn1 = 0;
    sg_comqn_t.qn2 = 0;
    sg_comqn_t.flag = 0;
	
	my_cjson_data_create_function(pdata,0); // ��ʼ
	/* �汾�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02x",COM_DATA_VERSION);
	my_cjson_join_string_function(pdata,(uint8_t *)"ver",(uint8_t *)temp,1);
//	my_cjson_join_string_function(pdata,(uint8_t *)"ver",(uint8_t *)"11",1);

	/* ID */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",device->id.i);
	my_cjson_join_string_function(pdata,(uint8_t *)"tid",(uint8_t *)temp,1);
	/* ͨ������ */
	my_cjson_join_string_function(pdata,(uint8_t *)"cmd",(uint8_t *)"E3",1);

	my_cjson_join_string_function(pdata,(uint8_t *)"mod",(uint8_t *)HARD_NO_STR,1);
	my_cjson_join_string_function(pdata,(uint8_t *)"sysver",(uint8_t *)SOFT_NO_STR,1);	

	/* �ն����к� */
	memset(temp,0,sizeof(temp));
	start_get_device_id_str((uint8_t*)temp);
	my_cjson_join_string_function(pdata,(uint8_t *)"tsn",(uint8_t *)temp,1);

	/* ǩ��У�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%x",crc);
	my_cjson_join_string_function(pdata,(uint8_t*)"crc",(uint8_t*)temp,0);
	
	my_cjson_data_create_function(pdata,1); // ����
	my_cjson_create_function(pdata,1); // ����
	
	*size = strlen((char*)pdata);
}

/************************************************************
*
* Function name	: com_ipc_ip_information
* Description	: �ϴ������IP��ַ
* Parameter		: 
* Return		: 
*	              20220329
************************************************************/
void com_ipc_ip_information(uint8_t *pdata, uint16_t *size)
{

}
/************************************************************
*
* Function name	: com_ipc_device_information
* Description	: �ϴ�������豸��Ϣ
* Parameter		: 
* Return		: 
*	              20220329
************************************************************/
int com_ipc_device_information(uint8_t *pdata, uint16_t *size)
{
   return 0;
} 

/************************************************************
*
* Function name	: com_gprs_lbs_information
* Description	: �ϴ���վ��λ��Ϣ
* Parameter		: 
* Return		: 
*	              20220329
************************************************************/
void com_gprs_lbs_information(uint8_t *pdata, uint16_t *size)
{
	struct device_param 	*device   = app_get_device_param_function();
	double longi_data = 0;
	double lati_data = 0;
	uint32_t dtemp	 = 0;
	char  temp[50] 	= {0};
	char  crc_buff[20]	= {0};
	uint8_t crc		    = 0;

	/* ����У���� */
	sprintf(crc_buff,"%x%dE1",0x10,device->id.i);
	crc = calc_crc8((uint8_t*)crc_buff,strlen(crc_buff)-1);	
	
	my_cjson_create_function(pdata,0); // ��ʼ
	my_cjson_join_int_function(pdata,(uint8_t *)"code",0,1);
	
	my_cjson_data_create_function(pdata,0); // ��ʼ
	
	/* ����QN */ 
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%08d%09d",sg_comqn_t.qn1,sg_comqn_t.qn2);
	my_cjson_join_string_function(pdata,(uint8_t *)"qn",(uint8_t *)temp,1);
	sg_comqn_t.qn1 = 0;
	sg_comqn_t.qn2 = 0;
	sg_comqn_t.flag = 0;
	
	/* �汾�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%02x",COM_DATA_VERSION);
	my_cjson_join_string_function(pdata,(uint8_t *)"ver",(uint8_t *)temp,1);
//	my_cjson_join_string_function(pdata,(uint8_t *)"ver",(uint8_t *)"11",1);		
	/* ID */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%d",device->id.i);
	my_cjson_join_string_function(pdata,(uint8_t *)"tid",(uint8_t *)temp,1);
	/* ͨ������ */
	my_cjson_join_string_function(pdata,(uint8_t *)"cmd",(uint8_t *)"E6",1);

	memset(temp,0,sizeof(temp));
	longi_data = gsm_get_location_information_function(0);
	temp[0] = (uint16_t)longi_data;
	dtemp   = (longi_data - temp[0]) * 100000000;
	sprintf((char*)temp,"%d.%08d,", temp[0], dtemp);
	my_cjson_join_string_function(pdata,(uint8_t*)"longitude",(uint8_t*)temp,1);
	
	lati_data	 = gsm_get_location_information_function(1);
	memset(temp,0,sizeof(temp));
	temp[0] = (uint16_t)lati_data;
	dtemp   = (lati_data - temp[0]) * 100000000;
	sprintf((char*)temp,"%d.%08d,", temp[0], dtemp);
	my_cjson_join_string_function(pdata,(uint8_t*)"latitude",(uint8_t*)temp,1);

	/* ǩ��У�� */
	memset(temp,0,sizeof(temp));
	sprintf(temp,"%x",crc);
	my_cjson_join_string_function(pdata,(uint8_t*)"crc",(uint8_t*)temp,0);
	
	my_cjson_data_create_function(pdata,1); // ����
	my_cjson_create_function(pdata,1); // ����	
	*size = strlen((char*)pdata);
	
//	printf("%s \r\n",pdata);
}

/************************************************************
*
* Function name	: com_deal_configure_server_domain_name
* Description	: �������÷�������������
* Parameter		: 
* Return		: 
*	
************************************************************/
int8_t com_deal_configure_server_domain_name(com_rec_data_t *buff)
{
	struct remote_ip *remote     = app_get_remote_network_function();
	sys_backups_t    *param_back = app_get_backups_function();
	struct update_addr *ota_p    = app_get_http_ota_function();
  int temp[4] = {0};
	int port[1] = {0};
	int8_t ret = 0;
	char *p1 = NULL;
	char *p2 = NULL;
	uint8_t mode  = 0;
	
	p1 = strstr((char*)buff->buff,"outer##");
	if (p1 != NULL) {
		memset(remote->outside_iporname,0,sizeof(remote->outside_iporname));
		p1 += 7;
		sscanf((char*)p1,"%[^:]:%d",remote->outside_iporname,&remote->outside_port);
		mode = 1;
		goto EXIT;
	}
		
	p1 = strstr((char*)buff->buff,"all##");
	if (p1 != NULL) 
	{
		p1 += 5;
		p2 = p1;
		p1 = strchr((char*)p1,',');
		if( p1 != NULL ) 
		{
			p1[0] = 0;
			p1	 += 1;
			
			app_save_backups_remote_param_function();  // ���ݷ�������Ϣ
			memset(remote->inside_iporname,0,sizeof(remote->inside_iporname));
			memset(remote->outside_iporname,0,sizeof(remote->outside_iporname));
			sscanf((char*)p2,"%[^:]:%d",remote->inside_iporname,&remote->inside_port);
			sscanf((char*)p1,"%[^:]:%d",remote->outside_iporname,&remote->outside_port);
		}
		mode = 1;
		goto EXIT;
	}
	
	p1 = strstr((char*)buff->buff,"update##");
	if (p1 != NULL) {
		memset(ota_p->ip,0,sizeof(ota_p->ip));
		p1 += 8;
		ret = sscanf(p1,"%d.%d.%d.%d:%d",&temp[0],&temp[1],&temp[2],&temp[3],&port[0]);
    ota_p->ip[0] = temp[0];
		ota_p->ip[1] = temp[1];
		ota_p->ip[2] = temp[2];
		ota_p->ip[3] = temp[3];
		ota_p->port  = port[0];
//		sscanf((char*)p1,"%[^:]:%d",ota_p->update_url,&ota_p->update_port);
		mode = 3;
		goto EXIT;
	}
	
	if ( p1 == NULL ) {
		/* ���ûش� */
		app_set_reply_parameters_function(buff->cmd,0x74);
		return ret;
	}
	EXIT:
	/* ���ûش� */
	app_set_send_result_function(SR_OK);
	app_set_reply_parameters_function(buff->cmd,0x01);
	OSTimeDlyHMSM(0,0,0,100);  			// ��ʱ10ms
	
	switch(mode)
	{
		case 1:app_set_save_infor_function(SAVE_REMOTE_IP); break;
		case 2:app_set_save_infor_function(SAVE_ONLY_SEND_IP); break;
		case 3:app_set_http_ota_function(*ota_p);  break;
		default:  break;
	}
	return ret;
}

/************************************************************
*
* Function name	: com_deal_configure_server_mode
* Description	: ���÷�����ģʽ
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_configure_server_mode(com_rec_data_t *buff)
{
	struct local_ip_t *local = app_get_local_network_function();

	local->server_mode = buff->buff[0];
	app_set_send_result_function(SR_OK);
	app_set_reply_parameters_function(buff->cmd,0x01);
	OSTimeDlyHMSM(0,0,0,100);  			// ��ʱ10ms
	app_set_save_infor_function(SAVE_LOCAL_NETWORK);
}

/************************************************************
*
* Function name	: com_deal_update_system_function
* Description	: ��������
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_update_system_function(com_rec_data_t *buff)
{
	/* ���ûش� */
	if( update_get_mode_function() != UPDATE_MODE_NULL) 
	{
		app_set_reply_parameters_function(buff->cmd,0x77);  // �������ڸ���
	} 
	else 
	{
		app_set_reply_parameters_function(buff->cmd,0x01);
		OSTimeDlyHMSM(0,0,0,200); 
		if(app_get_network_mode() == SERVER_MODE_GPRS)
			update_set_update_mode(UPDATE_MODE_GPRS); 
		else
			update_set_update_mode(UPDATE_MODE_LWIP); 
	}	
}

/************************************************************
*
* Function name	: com_set_now_time_function
* Description	: ���õ�ǰʱ��
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_now_time_function(com_rec_data_t *buff)
{
	uint32_t time = buff->buff[0];
	
	time = (time<<8)|buff->buff[1];
	time = (time<<8)|buff->buff[2];
	time = (time<<8)|buff->buff[3];
	
	TimeBySecond(time);
}

/************************************************************
*
* Function name	: com_set_ipc_time_function
* Description	: ���������ʱ��
* Parameter		: 
* Return		: 
*								20220329
************************************************************/
void com_set_ipc_time_function(com_rec_data_t *buff)
{

}

/************************************************************
*
* Function name	: com_deal_configure_server_ip_port
* Description	: �������÷�����IP�˿�
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_configure_server_ip_port(com_rec_data_t *buff)
{
	struct remote_ip *remote = app_get_remote_network_function();
	uint16_t temp = 0;
	
	memset(remote->inside_iporname,0,sizeof(remote->inside_iporname));
	sprintf((char*)remote->inside_iporname,"%d.%d.%d.%d",buff->buff[0],\
														 buff->buff[1],\
														 buff->buff[2],\
														 buff->buff[3]);
	temp = buff->buff[4];
	remote->inside_port = (temp<<8)|buff->buff[5];
	
	/* �洢 */
	app_set_save_infor_function(SAVE_REMOTE_IP);
	
	/* ���ûش� */
	app_set_reply_parameters_function(buff->cmd,0x01);
}

/************************************************************
*
* Function name	: com_deal_configure_local_network
* Description	: �����豸IP���������롢����
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_configure_local_network(com_rec_data_t *buff)
{
	struct local_ip_t *local = app_get_local_network_function();
	
	local->ip[0] = buff->buff[0];
	local->ip[1] = buff->buff[1];
	local->ip[2] = buff->buff[2];
	local->ip[3] = buff->buff[3];
	
	local->netmask[0] = buff->buff[4];
	local->netmask[1] = buff->buff[5];
	local->netmask[2] = buff->buff[6];
	local->netmask[3] = buff->buff[7];
	
	local->gateway[0] = buff->buff[8];
	local->gateway[1] = buff->buff[9];
	local->gateway[2] = buff->buff[10];
	local->gateway[3] = buff->buff[11];

	/* ���ûش� */
	app_set_send_result_function(SR_OK);
	app_set_reply_parameters_function(buff->cmd,0x01);
	OSTimeDlyHMSM(0,0,0,100);  			// ��ʱ10ms
	
	/* ���� */
	app_set_save_infor_function(SAVE_LOCAL_NETWORK);
	eth_set_network_reset();
	
}

/************************************************************
*
* Function name	: com_deal_configure_mac
* Description	: �����豸mac
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_configure_mac(com_rec_data_t *buff)
{
	struct local_ip_t *local = app_get_local_network_function();
	
	local->mac[0] = buff->buff[0];
	local->mac[1] = buff->buff[1];
	local->mac[2] = buff->buff[2];
	local->mac[3] = buff->buff[3];
	local->mac[4] = buff->buff[4];
	local->mac[5] = buff->buff[5]; 
	
	/* ���ûش� */
	app_set_send_result_function(SR_OK);
	app_set_reply_parameters_function(buff->cmd,0x01);
	OSTimeDlyHMSM(0,0,0,100);  			// ��ʱ10ms
	
	/* ���� */
	STMFLASH_Write_SAVE(DEVICE_FLASH_STORE,DEVICE_MAC_ADDR,(uint32_t *)&local->mac,2);
//	STMFLASH_Write(DEVICE_MAC_ADDR,(uint32_t *)&local->mac,2);
	app_set_save_infor_function(SAVE_LOCAL_NETWORK);
	eth_set_network_reset();
	
}

/************************************************************
*
* Function name	: com_deal_configure_device_id
* Description	: �����豸ID
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_configure_device_id(com_rec_data_t *buff)
{
	struct device_param  *param  = app_get_device_param_function();
		
	/* ��ȡID */
	param->id.i   = (buff->buff[0]<<16)|(buff->buff[1]<<8)|(buff->buff[2]<<0);
	
	/* ���ûش� */
	app_set_send_result_function(SR_OK);
	app_set_reply_parameters_function(buff->cmd,0x01);
	OSTimeDlyHMSM(0,0,0,100);  			// ��ʱ10ms
	
	/* ���� */
	STMFLASH_Write_SAVE(DEVICE_FLASH_STORE,DEVICE_ID_ADDR,(uint32_t*)param->id.c,1);
//	STMFLASH_Write(DEVICE_ID_ADDR,(uint32_t*)param->id.c,1);
	app_set_save_infor_function(SAVE_DEVICE_PARAM);
	
	OSTimeDlyHMSM(0,0,0,100);
	eth_set_tcp_connect_reset();				/* ����TCP���� */
	gsm_set_module_reset_function();				/* ������������ */
}


/************************************************************
*
* Function name	: com_deal_configure_onvif_carema
* Description	: onvif���������IP
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_configure_onvif_carema(com_rec_data_t *buff)
{

	/* ���ûش� */
	app_set_reply_parameters_function(buff->cmd,0x74);
}

/************************************************************
*
* Function name	: com_deal_camera_config
* Description	: ������������ͷ��Ϣ
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_camera_config(com_rec_data_t *buff)
{
	uint8_t num   = buff->buff[0]-1;
	uint8_t ip[4] = {0};
	int8_t  ret   = 0;
	
	ip[0] = buff->buff[1];
	ip[1] = buff->buff[2];
	ip[2] = buff->buff[3];
	ip[3] = buff->buff[4];
	
	if( ip[0] == 0 &&ip[1] == 0 &&ip[2] == 0 &&ip[3] == 0)
	{
		/* ���ָ��IP */
		app_set_camera_num_function(ip,num);
		app_set_reply_parameters_function(buff->cmd,0x01);
	}
	else
	{
		ret = app_match_local_camera_ip(ip);
		if(ret != 0)
		{
			/* ���ûش� */
			app_set_reply_parameters_function(buff->cmd,0x74); // IP�Ѵ���
		}
		else
		{
			app_set_camera_num_function(ip,num);
			app_set_reply_parameters_function(buff->cmd,0x01);
		}
	}
}

/************************************************************
*
* Function name	: com_deal_camera_config
* Description	: ��������ͷ�û���������
* Parameter		: 
* Return		: 
*								20220329
************************************************************/
void com_deal_camera_login(com_rec_data_t *buff)
{

}
/************************************************************
*
* Function name	: com_del_device_name
* Description	: 
* Parameter		: 
* Return		: 
*	          20220416 �¼������豸����
************************************************************/
void com_set_device_name_function(com_rec_data_t *buff)
{
	struct device_param *param = app_get_device_param_function();
	uint8_t		  size				 = 0;
	
	memset(param->name,0,sizeof(param->name));
	size = strlen((const char*)(buff->buff));
//	printf("zhongwen:");
//	for(uint8_t i=0;i<size;i++)
//		printf("%x",buff->buff[i]);
	
	if(size ==0)
	{
		app_set_reply_parameters_function(buff->cmd,0x74);		/* ���� */
	}
	else
	{
		for(uint8_t index=0; index<size; index++) 
		{
			param->name[index] = buff->buff[index];
		}	
		app_set_save_infor_function(SAVE_DEVICE_PARAM);	/* �洢 */
		app_set_reply_parameters_function(buff->cmd,0x01);	/* ���ûش� */
	}
//	for(uint8_t i=0;i<size;i++)
//		printf("%x",param->name[i]);
}

/************************************************************
*
* Function name	: com_set_threshold_params_function
* Description	: ������ֵ
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_threshold_params_function(com_rec_data_t *buff)
{	
	uint16_t data[5]={0};
	
	data[0] = (buff->buff[0]<<8|buff->buff[1]); // ǰ2���ֽ�
	data[1] = (buff->buff[2]<<8|buff->buff[3]); // ǰ2���ֽ�
	data[2] = (buff->buff[4]<<8|buff->buff[5]); // ǰ2���ֽ�
	data[3] = (buff->buff[7]);
	data[4] = (buff->buff[8]<<8|buff->buff[9]);
	
	app_set_vol_current_param(data);	/* �洢 */
	app_set_reply_parameters_function(buff->cmd,0x01);
}

/************************************************************
*
* Function name	: com_set_onvif_time_function
* Description	: ������������Э��ʱ��
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_onvif_time_function(com_rec_data_t *buff)
{	
	uint8_t  time  = buff->buff[0];

	if(time < 5)
	{
		app_set_reply_parameters_function(buff->cmd,0x74);		/* ���ûش� */
	}
	else
	{
		app_set_onvif_reload_time(time,0);
		app_set_reply_parameters_function(buff->cmd,0x01);		/* ���ûش� */
	}
}

/************************************************************
*
* Function name	: com_set_device_reload_time_function
* Description	: ��������ʱ��
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_device_reload_time_function(com_rec_data_t *buff)
{	
	uint8_t  time  = buff->buff[0];

	if((time < 24) &&( time > 168))
	{
		app_set_reply_parameters_function(buff->cmd,0x74);		/* ���ûش� */
	}
	else
	{
		app_set_onvif_reload_time(time,1);
		app_set_reply_parameters_function(buff->cmd,0x01);		/* ���ûش� */
	}
}

/************************************************************
*
* Function name	: com_set_onvif_mode_function
* Description	: ������������Э��ģʽ
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_onvif_mode_function(com_rec_data_t *buff)
{	
	uint8_t  mode  = buff->buff[0];

	if((mode==0)||(mode > 3))
	{
		app_set_reply_parameters_function(buff->cmd,0x74);		/* ���ûش� */
	}
	else
	{
		app_set_carema_search_mode_function(mode,1);
		app_set_reply_parameters_function(buff->cmd,0x01);		/* ���ûش� */
	}
}
/************************************************************
*
* Function name	: com_deal_fan_temp_parmaeter
* Description	: ���������¶�
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_fan_temp_parmaeter(com_rec_data_t *buff)
{
	int8_t data[2] = {0};
	
	data[0] = buff->buff[0];
	data[1] = buff->buff[1];
	
	app_set_fan_param_function(data);

	/* ���ûش� */
	app_set_reply_parameters_function(buff->cmd,0x01);
}

/************************************************************
*
* Function name	: com_deal_fan_humi_param
* Description	: ���÷�������ʪ�Ȳ���
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_fan_humi_param(com_rec_data_t *buff)
{
	uint8_t data[2] = {0};
	
	data[0] = buff->buff[0];
	data[1] = buff->buff[1];
	
	app_set_fan_humi_param_function(data);
	app_set_reply_parameters_function(buff->cmd,0x01);
}

/************************************************************
*
* Function name	: com_set_next_report_time
* Description	: �����ϱ����ʱ��
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_next_report_time(com_rec_data_t *buff)
{
	uint8_t  sel  = buff->buff[0];
	uint16_t time = (buff->buff[1]<<8|buff->buff[2]);

	if(time == 0)
	{
		/* ���ûش� */
		app_set_reply_parameters_function(buff->cmd,0x74);
	}
	else
	{
		app_set_next_report_time_other(time,sel);
		/* ���ûش� */
		app_set_reply_parameters_function(buff->cmd,0x01);
	}
	
}

/************************************************************
*
* Function name	: com_set_next_ping_time
* Description	: ����ping��ʱ����
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_next_ping_time(com_rec_data_t *buff)
{
	uint16_t time 	  = (buff->buff[0]<<8|buff->buff[1]); // ǰ2���ֽ�
	uint8_t	 time_dev = buff->buff[2];					  // ��1���ֽ�
	
	if(time == 0)
	{
		/* ���ûش� */
		app_set_reply_parameters_function(buff->cmd,0x74);
	}
	else
	{
		/* ������� */
		app_set_next_ping_time(time, time_dev);
		
		/* ���ûش� */
		app_set_reply_parameters_function(buff->cmd,0x01);
	}
}

/************************************************************
*
* Function name	: com_set_network_delay_time
* Description	: // ����������ʱʱ��		  20220308
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_network_delay_time(com_rec_data_t *buff)
{
	uint8_t	 time = buff->buff[0];				
	
	if(time == 0)
	{
		app_set_reply_parameters_function(buff->cmd,0x74);		/* ���ûش� */
	}
	else
	{
		app_set_network_delay_time(time);		/* ������� */
		app_set_reply_parameters_function(buff->cmd,0x01);		/* ���ûش� */
	}
}

/************************************************************
*
* Function name	: com_set_device_password
* Description	:  ��������
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_device_password(com_rec_data_t *buff)
{
  struct device_param 	*device = app_get_device_param_function();
	memset(device->password,0,sizeof(device->name));
	sprintf((char*)device->password,DEFALUT_PASSWORD);
	device->default_password = 1; // Ĭ�Ͽ�����Ҫ�޸�����
	
	app_set_save_infor_function(SAVE_DEVICE_PARAM);	/* �洢 */
	app_set_reply_parameters_function(buff->cmd,0x01);	/* ���ûش� */	
	
}

/************************************************************
*
* Function name	: com_set_main_ping_ip
* Description	: ��������pingip
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_main_ping_ip(com_rec_data_t *buff)
{
	uint8_t ip[8];
	
	ip[0] = buff->buff[0];
	ip[1] = buff->buff[1];
	ip[2] = buff->buff[2];
	ip[3] = buff->buff[3];
	
	ip[4] = buff->buff[4];
	ip[5] = buff->buff[5];
	ip[6] = buff->buff[6];
	ip[7] = buff->buff[7];
	
	app_set_main_network_ping_ip(ip);
	
	/* ���ûش� */
	app_set_reply_parameters_function(buff->cmd,0x01);	
}

/************************************************************
*
* Function name	: com_set_work_time
* Description	: �������š�����ƹ���ʱ���
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_set_work_time(com_rec_data_t *buff,uint8_t mode)
{
	int time[4]		= {0};
	uint16_t temp[2] = {0};

	sscanf((char*)buff->buff,"%d:%d-%d:%d",&time[0],&time[1],&time[2],&time[3]);
	for(uint8_t i=0;i<4;i++)
	{
		if(time[i] < 0)
			time[i] = 0;	
	}
	if(time[0] > 23)
		time[0] = 23;

	if(time[2] > 23)
		time[2] = 23;
	
	if(time[1] > 59)
		time[1] = 59;

	if(time[3] > 59)
		time[3] = 59;
	
	temp[0] = time[0]*60+time[1];
	temp[1] = time[2]*60+time[3];
	if(mode == 0)
		app_set_door_time_function(temp);
	else
		app_set_fill_light_function(temp);
	app_set_reply_parameters_function(buff->cmd,0x01);
}


/************************************************************
*
* Function name	: com_deal_ack_parameter
* Description	: �����ظ�����
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_deal_ack_parameter(com_rec_data_t *buff)
{
	uint8_t error = buff->buff[0];
	
	if(error == 0x01)
	{
		app_set_send_result_function(SR_OK);
	}
	else
	{
		app_set_send_result_function(SR_ERROR);
	}
}

/************************************************************
*
* Function name	: com_query_processing_function
* Description	: ��ѯ��������
* Parameter		: 
* Return		: 
*	�޸ģ� ���������ID�� 20220329
************************************************************/
void com_query_processing_function(uint8_t query, uint8_t data)
{
	app_set_com_send_flag_function(query,data);
}


/************************************************************
*
* Function name	: com_recevie_function_init
* Description	: ͨ�Ž��ճ�ʼ������
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_recevie_function_init(void)
{
	com_cache_initialization(COM_MALLOC_SIZE);
}

/************************************************************
*
* Function name	: com_deal_main_function
* Description	: ͨ�Ž��մ�������
* Parameter		: 
* Return		: 
*	
************************************************************/
int8_t com_deal_main_function(void)
{
	struct device_param *device      	= app_get_device_param_function();
	com_rec_data_t      recdata_t    	= {0};
	uint32_t 						temp		 			= 0;
	uint8_t 	        	rec_buff[100] = {0};
	uint8_t 	        	size		 			= 0;
	uint8_t 	        	crc			 			= 0;
	uint8_t 		    		ret			 			= 0;
	
	size = com_queue_find_msg(rec_buff,100);
	if(size != 0)
	{

		/* У��CRC:ȥ��crcУ��������β */
		crc = calc_crc8(&rec_buff[2],size-5);
		if(crc != rec_buff[size-3])
		{
			/* CRCУ����� */
			ret = CR_CHECK_ERROR;
			app_set_reply_parameters_function(recdata_t.cmd,ret);
			goto __ERROR;
		}
		rec_buff[size-3] = 0; // ��CRCУ���Ӧ������ֱ��ת��Ϊ�ַ���β
		
		/* ��ȡ�汾 */
		recdata_t.version = rec_buff[2];
		/* ��ȡID */
		recdata_t.id      = (rec_buff[3]<<16)|(rec_buff[4]<<8)|(rec_buff[5]<<0);
		
		/* ���ݰ汾 */
		if(recdata_t.version != COM_DATA_VERSION)
//		if(recdata_t.version != COM_NUM_VAERSION)
		{
			/* ���ݰ汾���� */
			goto __ERROR;
		}
		
		/* ��ȡָ������ */
		recdata_t.cmd     = rec_buff[6];
		
		/* ID��֤ */
		if(recdata_t.id != device->id.i && recdata_t.cmd != CONFIGURE_NOW_TIME)
		{
			/* ID���� */
			ret = CR_DEVICE_NUMBER_ERROR;
			app_set_reply_parameters_function(recdata_t.cmd,ret);
			goto __ERROR;
		}
		
		/* ��ȡ�����ʶ�� */
		temp = rec_buff[7];
		temp = (temp<<8)|rec_buff[8];
		temp = (temp<<8)|rec_buff[9];
		temp = (temp<<8)|rec_buff[10];
		sg_comqn_t.qn1 = temp;
		temp = rec_buff[11];
		temp = (temp<<8)|rec_buff[12];
		temp = (temp<<8)|rec_buff[13];
		temp = (temp<<8)|rec_buff[14];
		sg_comqn_t.qn2 = temp;
		/* ��ȡ���� */
		recdata_t.size    = rec_buff[15];
		/* ��ȡ���� */
		recdata_t.buff    = &rec_buff[16];
		
		/* ��������������� */
		switch(recdata_t.cmd)
		{
			/* ����ָ�� */
			case CONFIGURE_SERVER_DOMAIN_NAME:  // ���÷�������Ϣ
				com_deal_configure_server_domain_name(&recdata_t);
				break;
			case CONFIGURE_LOCAL_NETWORK: 		// ���ñ���������Ϣ
				com_deal_configure_local_network(&recdata_t);
				break;
			case CONFIGURE_CAMERA_CONFIG:		// ��������ͷIP
				com_deal_camera_config(&recdata_t);
				break;
			case CONFIGURE_IPC_LOGIN_INFO:		// ��������ͷ�û���������  20220329
				com_deal_camera_login(&recdata_t);
				break;
			case CONFIGURE_FAN_PARAMETER:		// ���÷����¶�
				com_deal_fan_temp_parmaeter(&recdata_t);
				break;
			case CONFIGURE_HEART_TIME:			// �����ϱ�ʱ��
				com_set_next_report_time(&recdata_t);
				break;
			case CONFIGURE_PING_INTERVAL:		// ����ping���ʱ��
				com_set_next_ping_time(&recdata_t);
				break;
			case CONFIGURE_NETWORK_DELAY:		// ����������ʱʱ��		  20220308
				com_set_network_delay_time(&recdata_t);
				break;
			case CONFIGURE_MAIN_NETWORK_IP:     // ����������
				com_set_main_ping_ip(&recdata_t);
				break;
			case CONFIGURE_FAN_HUMI:			// ���÷���ʪ��
				com_deal_fan_humi_param(&recdata_t);
				break;
			case CONFIGURE_SERVER_MODE:			// ������������ģʽ
				com_deal_configure_server_mode(&recdata_t);
				break;
			case CONFIGURE_UPDATE_SYSTEM:		// ����ϵͳ����
				com_deal_update_system_function(&recdata_t);
				break;
			case CONFIGURE_NOW_TIME:		   	  // ���õ�ǰʱ��
				com_set_now_time_function(&recdata_t);
				break;
			case CONFIGURE_IPC_TIME_SYNC:			// ���������ʱ��  20220329
				com_set_ipc_time_function(&recdata_t);
				break;
			case CONFIGURE_DEVICE_NAME:				// �����豸����  20220416
				com_set_device_name_function(&recdata_t);
				break;
			case CONFIGURE_THRESHOLD_PARAMS:	// ������ֵ  20230721
				com_set_threshold_params_function(&recdata_t);
				break;
			case CONFIGURE_ONVIF_TIME:				// ��������Э��ʱ��  20230721
				com_set_onvif_time_function(&recdata_t);
				break;
			case CONFIGURE_SEARCH_MODE:				// ��������Э��ģʽ  20230721
				com_set_onvif_mode_function(&recdata_t);
				break;
			case CONFIGURE_DEVICE_PASSWORD:		// ����ָ�����
				com_set_device_password(&recdata_t);
				break;
			case CONFIGURE_DEVICE_ID: 			// �����豸ID  20231026
				com_deal_configure_device_id(&recdata_t);
				break;
			case CONFIGURE_ONVIF_CAREMA: 		 // ����Э�����������IP  20240201
				com_deal_configure_onvif_carema(&recdata_t);
				break;
			case CONFIGURE_RELOAD_TIME: 		 // �豸����
				com_set_onvif_time_function(&recdata_t);
				break;
			case CONFIGURE_FILL_LIGHT_TIME:		// ���ò����ʱ��
				com_set_work_time(&recdata_t,1);
				break;
			case CONFIGURE_DOOR_TIME:		      // ��������ʱ��
				com_set_work_time(&recdata_t,0);
				break;	
			
			
			/* ��ѯָ�� */
			case CR_QUERY_CONFIG: 			// ��ѯ�豸��ǰ�������� - ��Ӧ�ϴ���ѯ����
			case CR_QUERY_INFO:   			// �����ϱ��豸״̬	    - �����ϱ�
			case CR_QUERY_SOFTWARE_VERSION: // ��ѯ�豸�����汾��
			case CR_QUERY_IPC_IP:       		// ��ѯ�����IP��ַ    20220329
			case CR_QUERY_IPC_INFO:					// ��ѯ�������ز���  20220329
			case CR_QUERY_LBS_INFO:					// ��ѯ��վ��λ��Ϣ
				sg_comqn_t.flag = 1;
				com_query_processing_function(recdata_t.cmd,recdata_t.buff[0]-1);
				break;
			
			/* ����ָ�� */
			case CR_SINGLE_CAMERA_CONTROL:
			case CR_POWER_RESETART:
			case CR_GPRS_NETWORK_RESET:
			case CR_LWIP_NETWORK_RESET:
			case CR_IPC_REBOOT:            // IPC����  20220329
			case CR_GPRS_NETWORK_V_RESET:
			case CR_SINGLE_DC12_CONTROL:
				app_set_sys_opeare_function(recdata_t.cmd,recdata_t.buff[0]);
				break;
			
			/* ���ؿ��� */
			case CONTROL_FAN:
				app_set_peripheral_switch(recdata_t.cmd,recdata_t.buff[0]);
				break;
			
			default:
				com_deal_ack_parameter(&recdata_t);
				break;
		}
	} 
	else 
		size = 0;
	
	return ret;
__ERROR:
	return ret;
}

/*********************************************************
				���ݻ�����
**********************************************************/
com_queue_t sg_comqueue_t = {0};

static void com_queue_init(com_queue_t *queue);
/************************************************************
*
* Function name	: com_cache_initialization
* Description	: ��������ʼ��
* Parameter		: 
* Return		: 
* 
************************************************************/
void com_cache_initialization(uint16_t size)
{
	sg_comqueue_t.data = mymalloc(SRAMIN,size);
	sg_comqueue_t.size = size;
	mymemset(sg_comqueue_t.data,0,size);
	com_queue_init(&sg_comqueue_t);
}

/************************************************************
*
* Function name	: 
* Description	: 
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_queue_init(com_queue_t *queue)
{
	queue->front = 0;
	queue->rear  = 0;
}

/************************************************************
*
* Function name	: 
* Description	: 
* Parameter		: 
* Return		: 
*	
************************************************************/
uint8_t com_is_queue_empty(com_queue_t queue)
{
	return (queue.front == queue.rear?1:0);
}

/************************************************************
*
* Function name	: com_en_queue
* Description	: 
* Parameter		: 
* Return		: 
*	
************************************************************/
uint8_t com_en_queue(com_queue_t *queue,uint8_t data)
{
	uint16_t pos = (queue->front+1)%(queue->size);
	
	if(pos != queue->rear)
	{
		queue->data[queue->front] = data;
		queue->front = pos;
		return 1;
	}
	else
	{
//		mymemset(sg_comqueue_t.data,0,sg_comqueue_t.size);
//		com_queue_init(&sg_comqueue_t);
		return 0;
	}	
}

/************************************************************
*
* Function name	: 
* Description	: 
* Parameter		: 
* Return		: 
*	
************************************************************/
uint8_t com_de_queue(com_queue_t *queue,uint8_t *data)
{
	if(queue->rear == queue->front)
	{
//		mymemset(sg_comqueue_t.data,0,sg_comqueue_t.size);
//		com_queue_init(&sg_comqueue_t);
		return 0;
	}
	*data=queue->data[queue->rear];
	queue->rear=(queue->rear+1)%(queue->size);
	return 1;
}

/************************************************************
*
* Function name	: com_stroage_cache_data
* Description	: �����ݴ洢��������
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_stroage_cache_data(uint8_t *buff,uint16_t len)
{
	uint16_t index = 0;
	uint8_t  res   = 0;
	uint8_t  data  = 0;
	
	for(index=0; index<len; index++)
	{
		res = com_en_queue(&sg_comqueue_t,buff[index]);
		if(res == 0)
		{
			com_de_queue(&sg_comqueue_t,&data);
			com_en_queue(&sg_comqueue_t,buff[index]);
		}
	}
}

/************************************************************
*
* Function name	: com_storage_cache_full_data
* Description	: ��������
* Parameter		: 
* Return		: 
*	
************************************************************/
void com_storage_cache_full_data(void)
{
	uint8_t buff = 0xff;
	uint8_t index = 0;
	
	for(index=0; index<20; index++)
	{
		com_stroage_cache_data(&buff,1);
	}
}

/************************************************************
*
* Function name	: 
* Description	: 
* Parameter		: 
* Return		: 
*	
************************************************************/
uint16_t com_size_queue(com_queue_t queue)
{
	return ((queue.front+queue.size-queue.rear)%(queue.size));
}

static uint16_t msg_pos   = 0;

#define CUTDOWN_TIME (1000) // 1000x1ms
uint32_t com_cutdown_time = 0;

void com_queue_time_function(void)
{
	if(com_cutdown_time != 0) {
		com_cutdown_time--;
		if(com_cutdown_time == 0) {
			msg_pos = 0;
		}
	}
}

/*
##0163QN=20200730160101008;TID=123456;CMD=F5;CP=&&INNER=192.168.0.1:52369;OUTER=abc.fnwlw.net:52369;OUTER2=b2.fnwlw.net:52369;OUTER3=b3.fnwlw.net:52369;UPDATE=192.168.0.100:54333&&be##
*/
/************************************************************
*
* Function name	: com_queue_find_msg
* Description	: ��ȡ�������е�����
* Parameter		: 
* Return		: 
*	
************************************************************/
uint16_t com_queue_find_msg(uint8_t *msg,uint16_t size)
{
	static uint16_t msg_state = 0;
	static uint16_t	msg_head  = 0;
	static uint8_t  buff_size = 0;
	static uint8_t  buff_cmd  = 0;
	uint16_t 		msg_size  = 0;
	uint8_t  		msg_data  = 0;
	buff_cmd  =  buff_cmd;
	
	while(com_size_queue(sg_comqueue_t) > 0)
	{
		com_cutdown_time = CUTDOWN_TIME;
		com_de_queue(&sg_comqueue_t,&msg_data);
		
		msg_head = (msg_head<<8)|msg_data;
		if(msg_pos==0 && (msg_head != COM_REC_HAED_HEX))
		{
			continue;
		}
		/* �����һ���ֽڵ�����ͷ */
		if(msg_pos==0)
		{
			msg[msg_pos++] = (COM_REC_HAED_HEX>>8)&0xff;
			buff_size = 0;
		}
		if(msg_pos == 6) {
			buff_cmd = msg_data;
		}

		if(msg_pos == (7+8))
		{
			buff_size = msg_data;
		}
		
		if(msg_pos < size)
		{
			msg[msg_pos++] = msg_data;
		} 
		else 
		{
			msg_size  = 0;
			msg_state = 0;						//���¼��֡β��
			msg_pos   = 0;					    //��λָ��ָ��
			buff_size = 0;
			return msg_size;
		}
		
		msg_state = ((msg_state<<8)|msg_data); //ƴ�����2���ֽڣ����һ��16λ����
		
		/* ���2���ֽ���֡βƥ�䣬�õ�����֡ */
		if(msg_state == COM_TAIL_HEX && ((buff_size + 11 + 8) <= msg_pos))
		{
			msg_size  = msg_pos;				//ָ���ֽڳ���
			msg_state = 0;						  //���¼��֡β��
			msg_pos   = 0;					    //��λָ��ָ��
			buff_cmd  = 0;
			
			return msg_size;
		}
		
		/* Э�����ݳ������� */
		if((11+8+buff_size) <= msg_pos) {
			msg_size  = 0;
			msg_state = 0;						//���¼��֡β��
			msg_pos   = 0;					    //��λָ��ָ��
			buff_size = 0;
			return msg_size;
		}
	}
	return 0; 
}
