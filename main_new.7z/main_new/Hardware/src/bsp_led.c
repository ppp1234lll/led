#include "bsp_led.h"
#include "bsp.h"

/*
	2��ָʾ�ƣ�ԭ��ͼ����
		ϵͳ״ָ̬ʾ��  STATE      : PE6
		����ָʾ��      LAN        : PE5
		4Gָʾ��        GPRS       : PE4
*/
/******************************************************************************************/
/* ���� ���� */

#define LED_STATE_GPIO_PORT						GPIOE
#define LED_STATE_GPIO_PIN						GPIO_PIN_6
#define LED_STATE_GPIO_CLK_ENABLE()  	__HAL_RCC_GPIOE_CLK_ENABLE();

#define LED_LAN_GPIO_PORT				  		GPIOE
#define LED_LAN_GPIO_PIN				  		GPIO_PIN_5
#define LED_LAN_GPIO_CLK_ENABLE()  	  __HAL_RCC_GPIOE_CLK_ENABLE();

#define LED_GPRS_GPIO_PORT						GPIOE
#define LED_GPRS_GPIO_PIN							GPIO_PIN_3
#define LED_GPRS_GPIO_CLK_ENABLE()  	__HAL_RCC_GPIOE_CLK_ENABLE();
/******************************************************************************************/

#define LED_STATE(x)  	x ? \
												HAL_GPIO_WritePin(LED_STATE_GPIO_PORT, LED_STATE_GPIO_PIN, GPIO_PIN_RESET) : \
												HAL_GPIO_WritePin(LED_STATE_GPIO_PORT, LED_STATE_GPIO_PIN, GPIO_PIN_SET);  
#define LED_LAN(x)    	x ? \
												HAL_GPIO_WritePin(LED_LAN_GPIO_PORT, LED_LAN_GPIO_PIN, GPIO_PIN_RESET) : \
												HAL_GPIO_WritePin(LED_LAN_GPIO_PORT, LED_LAN_GPIO_PIN, GPIO_PIN_SET);  
#define LED_GPRS(x)   	x ? \
												HAL_GPIO_WritePin(LED_GPRS_GPIO_PORT, LED_GPRS_GPIO_PIN, GPIO_PIN_RESET) : \
												HAL_GPIO_WritePin(LED_GPRS_GPIO_PORT, LED_GPRS_GPIO_PIN, GPIO_PIN_SET);  

#define LED_STATE_TOG()   HAL_GPIO_TogglePin(LED_STATE_GPIO_PORT,LED_STATE_GPIO_PIN) 
#define LED_LAN_STA()     HAL_GPIO_TogglePin(LED_LAN_GPIO_PORT,LED_LAN_GPIO_PIN) 
#define LED_GPRS_TOG()    HAL_GPIO_TogglePin(LED_GPRS_GPIO_PORT,LED_GPRS_GPIO_PIN) 

/* ָʾ����˸ʱ��*/
#define FLICKER_TIME_Q	(200)
#define FLICKER_TIME 		(500)
#define FLICKER_TIME_1S (1000)

/* ָʾ��״̬����*/
typedef struct
{
	uint8_t gprs;
	uint8_t lan;
	uint8_t state;
	uint8_t lan_out;
	uint8_t power_out;
} led_flicker_t;

led_flicker_t sg_ledflicker_t = {0};

/*
*********************************************************************************************************
*	�� �� ��: bsp_InitLed
*	����˵��: ��ʼ��ָʾ�ƿ���io:Ĭ�ϲ�����
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_InitLed(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	
	LED_STATE_GPIO_CLK_ENABLE();
	LED_LAN_GPIO_CLK_ENABLE();
	LED_GPRS_GPIO_CLK_ENABLE();
	
	HAL_GPIO_WritePin(LED_STATE_GPIO_PORT,LED_STATE_GPIO_PIN, GPIO_PIN_SET);
	HAL_GPIO_WritePin(LED_LAN_GPIO_PORT,LED_LAN_GPIO_PIN, GPIO_PIN_SET);
	HAL_GPIO_WritePin(LED_GPRS_GPIO_PORT,LED_GPRS_GPIO_PIN, GPIO_PIN_SET);
	
  GPIO_InitStruct.Pin = LED_STATE_GPIO_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_STATE_GPIO_PORT, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LED_LAN_GPIO_PIN;
  HAL_GPIO_Init(LED_LAN_GPIO_PORT, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LED_GPRS_GPIO_PIN;
  HAL_GPIO_Init(LED_GPRS_GPIO_PORT, &GPIO_InitStruct);	
}

/*
*********************************************************************************************************
*	�� �� ��: led_control_function
*	����˵��: ����ָ����LEDָʾ�ơ�
*	��    ��:  dev  : ָʾ�����
*	           state: ָʾ��״̬
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void led_control_function(LD_DEV dev, LED_STATUS state)
{
	switch(dev)
	{
		case LD_STATE:  // ϵͳ����ָʾ��
			sg_ledflicker_t.state = state;
			switch(state) 
			{
        case LD_ON:	 LED_STATE(0);break;
        case LD_OFF: LED_STATE(1);break;
        default:break;
      }
      break;
			
		case LD_GPRS:  // 4Gָʾ��
			sg_ledflicker_t.gprs = state;
			switch(state) 
			{
        case LD_ON:			LED_GPRS(0);break;
        case LD_OFF:		LED_GPRS(1);break;
        default:break;
			}
			break;
			
		case LD_LAN:   // ����ָʾ��
			sg_ledflicker_t.lan = state;
			switch(state) 
			{
        case LD_ON:			LED_LAN(0);break;
        case LD_OFF:		LED_LAN(1);break;
        default:break;
			}
			break;

		default:		break;
	}
}

/*
*********************************************************************************************************
*	�� �� ��: led_flicker_control_timer_function
*	����˵��: led����
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void led_flicker_control_timer_function(void)
{
	static uint16_t count   = 0;
	static uint16_t count3	= 0;
	
	count++;
	if(count > FLICKER_TIME)
	{
		count = 0;
		if(sg_ledflicker_t.gprs == LD_FLICKER)		/* ��ʾ��������״̬ */
		{
			LED_GPRS_TOG();
		}

		if(sg_ledflicker_t.lan == LD_FLICKER)		/* ��ʾ��������״̬ */
		{
			LED_LAN_STA();
		} 
	
		if(sg_ledflicker_t.state == LD_FLICKER) 	/* ϵͳ״̬�� */
		{
			LED_STATE_TOG();
		}
	}

	count3++;
	if(count3 > FLICKER_TIME_Q)
	{
		count3 = 0;
		if(sg_ledflicker_t.gprs == LD_FLIC_Q)		/* ��ʾ��������״̬ */
			LED_GPRS_TOG();

		if(sg_ledflicker_t.lan == LD_FLIC_Q)		/* ��ʾ��������״̬ */
			LED_LAN_STA();
	}
}

/*
*********************************************************************************************************
*	�� �� ��: led_test
*	����˵��: led����
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void led_test(void)
{
	while(1)
	{
    HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3|GPIO_PIN_5|GPIO_PIN_6, GPIO_PIN_RESET);
		delay_ms(1000);
    HAL_GPIO_WritePin(GPIOE,GPIO_PIN_3|GPIO_PIN_5|GPIO_PIN_6, GPIO_PIN_SET);
		delay_ms(1000);	
	}
}
/******************************************  (END OF FILE) **********************************************/


