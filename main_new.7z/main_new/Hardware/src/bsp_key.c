#include "bsp_key.h"
#include "appconfig.h"
/*
	4��������
		����(�ָ���������):    PD4
		12V��Դ������:       PD0
		���ż��1:             PD15
		���ż��2:             PC8
		���ż��3:             PA11
		���ż��4:             PA12
		ˮ��1 :                PD11
    ˮ��2 :                PD14		

    �տ�ǰ220������ :    PE15
*/
#define RESET_KEY_READ 			HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_4)	 
#define PWR_TST_READ  		  HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_0)  
#define DOOR1_READ    	 		HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_15)   
#define DOOR2_READ   	 			HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_8)  
#define DOOR3_READ   	 		  HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_11)  
#define DOOR4_READ   	 		  HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_12)  
#define WATER1_READ   	 		HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_11)   
#define WATER2_READ   	 		HAL_GPIO_ReadPin(GPIOD,GPIO_PIN_14)
#define MCB_220_READ   	 		HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_15)
/*
*********************************************************************************************************
*	�� �� ��: bsp_InitKey
*	����˵��: ��ʼ������.  
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void bsp_InitKey(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
	
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
	
  /*Configure GPIO pin : PE15 */
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);	
  /*Configure GPIO pins : PD11 PD14 PD15 PD0
                           PD4 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0
                          |GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : PC8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA11 PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);	
	
}

/*
*********************************************************************************************************
*	�� �� ��: key_test
*	����˵��: ��������.  
*	��    ��: ��
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void key_test(void)
{
	while(1)
	{
		printf("RESET = %d...",RESET_KEY_READ);
		printf("PWR   = %d...",PWR_TST_READ);
		printf("DOOR1 = %d...",DOOR1_READ);
		printf("DOOR2 = %d...",DOOR2_READ);
		printf("DOOR3 = %d...",DOOR3_READ);
		printf("DOOR4 = %d...",DOOR4_READ);
		printf("WATER1= %d...",WATER1_READ);
		printf("WATER2= %d...",WATER2_READ);
		printf("220IN = %d\n ",MCB_220_READ);		
		
		delay_ms(1000);		
	}
}

